echo 'Blank floppy image generator'
echo 'What is the file name that you want (also add .img at the end unless you know what your doing?)'
read fname

head -c 1509949 /dev/zero > $fname

