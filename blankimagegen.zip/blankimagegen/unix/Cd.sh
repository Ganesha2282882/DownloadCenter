echo 'Blank CD image generator'
echo 'What is the file name that you want (also add .iso at the end unless you know what your doing?)'
read fname

head -c 734003200 /dev/zero > $fname

